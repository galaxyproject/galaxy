first tar member
