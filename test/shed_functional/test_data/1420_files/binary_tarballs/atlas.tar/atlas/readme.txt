If this was an actual tool dependency, ATLAS would now be installed in this location.
