If this was an actual tool dependency, numpy would now be installed in this location.
