If this was an actual tool dependency, bzlib would now be installed in this location.
