#!/usr/bin/env python
#Dan Blankenberg
#Script that simulates a basic Data Manager tool executable

import optparse
import os

from galaxy.util.json import from_json_string, to_json_string

BASE_FILENAME = 'some built-in.file'

def main():
    #Parse Command Line
    parser = optparse.OptionParser()
    parser.add_option( '-f', '--filename', dest='filename', action='store', type='string', default=None, help='filename' )
    parser.add_option( '-t', '--tool_data_table_name', dest='tool_data_table_name', action='store', type='string', default=None, help='tool_data_table_name' )
    (options, args) = parser.parse_args()
    
    params = from_json_string( open( options.filename ).read() )
    target_directory = params[ 'output_data' ][0]['extra_files_path']
    dbkey = params['param_dict']['dbkey']
    value = params['param_dict']['data_id']
    data_name = params['param_dict']['data_name']
    os.mkdir( target_directory )
    with open( os.path.join( target_directory, BASE_FILENAME ), 'wb' ) as fh:
        fh.write( '\000\001\002' )
    data_table_entry = { 'value':value, 'dbkey': dbkey, 'name':data_name, 'path': BASE_FILENAME }
    data_manager_dict = { 'data_tables': { options.tool_data_table_name: [ data_table_entry ]  } }
    
    #save info to json file
    with open( options.filename, 'wb' ) as fh:
        fh.write( to_json_string( data_manager_dict ) )

if __name__ == "__main__":
    main()
