If this was an actual tool dependency, LAPack would now be installed in this location.
