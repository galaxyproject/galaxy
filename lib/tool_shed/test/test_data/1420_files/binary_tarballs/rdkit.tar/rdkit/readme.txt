If this was an actual tool dependency, RDkit would now be installed in this location.
